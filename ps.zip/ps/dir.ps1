﻿#Create SSL certificate for WIndows VMs
# Get the IP address of the Ethernet interface
$IP = (Get-NetIPAddress -InterfaceAlias "Ethernet*" -AddressFamily IPv4).IPAddress
echo "IP: $IP"

# Create the self-signed certificate
$Certificate = New-SelfSignedCertificate -DnsName $env:COMPUTERNAME, $IP -CertStoreLocation "Cert:\LocalMachine\My"
$CertificateThumbprint = $Certificate.Thumbprint

echo "Certificate Thumbprint: $CertificateThumbprint"

# Create the WinRM listener
$listener = @{
    ResourceURI   = "winrm/config/Listener"
    SelectorSet   = @{ Address = "*"; Transport = "HTTPS" }
    ValueSet      = @{ CertificateThumbprint = $CertificateThumbprint }
}
New-WSManInstance @listener

# Enable Basic authentication for WinRM
Set-WSManInstance -ResourceURI "winrm/config/service/auth" -ValueSet @{ Basic = $true }

# Create the firewall rule for WinRM over HTTPS
$rule = @{
    Name        = "WINRM-HTTPS-In-TCP"
    DisplayName = "Windows Remote Management (HTTPS-In)"
    Description = "Inbound rule for Windows Remote Management via WS-Management over TCP 5986"
    Enabled     = "true"
    Direction   = "Inbound"
    Profile     = "Any"
    Action      = "Allow"
    Protocol    = "TCP"
    LocalPort   = "5986"
}
New-NetFirewallRule @rule
